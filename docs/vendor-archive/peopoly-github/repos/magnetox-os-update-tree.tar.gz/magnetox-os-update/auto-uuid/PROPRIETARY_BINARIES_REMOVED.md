Magmotor and MagnetoWifiHelper omitted from public archive (proprietary).
